package model;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import java.util.Date;

	import javax.swing.JComboBox;
	import javax.swing.JOptionPane;
	import javax.swing.JTable;
	import javax.swing.JTextField;



	import model.Absence;
	import view.GestionAbs;

	import net.proteanit.sql.DbUtils;
	import model.Connect;
public class EventDao {
		    JTable table;
	        JTextField field;
		    Connect con;
			ResultSet rs;
			/**
			 * Methode pour ajouter des evenements.
			 */
		
		public void addEvent(JTable table,String nom, String description,String date_debut,String date_fin,String lieu){
			PreparedStatement myStmt = null;
			try {
		    	   String sql="insert into evenement(Nom,Description,Date_Debut,Date_Fin,Lieu) values (?,?,?,?,?)";
						myStmt = Connect.ConnectDb().prepareStatement(sql);
						myStmt.setString(1, nom);
						myStmt.setString(2, description);
						myStmt.setString(3, date_debut);
						myStmt.setString(4, date_fin);
						myStmt.setString(5, lieu);
						myStmt.executeUpdate();
						JOptionPane.showMessageDialog(null, "Evenement Ajout�e ");
						UpdateTable(table);
					}
						
					catch(SQLException e1) {
						e1.printStackTrace();
					}
		}
							   
		/**
		 * Methode pour modifier des evenements.
		 */
		public void updateEvent(  JTable table,String nom,String Description,String DateDebut,String DateFin,String Lieu ) throws SQLException {
			PreparedStatement myStmt = null;

			int ligne =table.getSelectedRow();
			if(ligne==-1) {
				JOptionPane.showMessageDialog(null, "S�lectionnez une absence");
			}
			else
			{
				String id=table.getModel().getValueAt(ligne,0).toString();
				String sql="Update evenement set Nom=?,Description=?,Date_Debut=?,Date_Fin=?, Lieu=? WHERE ID_event='"+id+"'";
				try {
					myStmt= Connect.ConnectDb().prepareStatement(sql);
					myStmt.setString(1, nom);
					myStmt.setString(2, Description);
					myStmt.setString(3, DateDebut);
					myStmt.setString(4, DateFin);
					myStmt.setString(5, Lieu);
					myStmt.executeUpdate();
				JOptionPane.showMessageDialog(null, "Evenement modifi�");
				UpdateTable(table);
			
				}catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		/**
		 * Methode pour supprimer des evenements.
		 */
		public void deleteEvent(JTable table) {
			PreparedStatement myStmt=null;
			PreparedStatement myStmt1=null;
			int ligne =table.getSelectedRow();
			if(ligne==-1) {
				JOptionPane.showMessageDialog(null, "S�lectionnez un evenement");
			}
			else
			{String nom=table.getModel().getValueAt(ligne,1).toString();
				String id=table.getModel().getValueAt(ligne,0).toString();
				//System.out.println(id);
				String sql="delete FROM evenement WHERE ID_event='"+id+"'";
				String sql1="delete from statistique where Nom='"+nom+"'";
				try {
					myStmt = Connect.ConnectDb().prepareStatement(sql);
					myStmt1=Connect.ConnectDb().prepareStatement(sql1);
					myStmt.executeUpdate();
					myStmt1.executeUpdate();
					JOptionPane.showMessageDialog(null, "Evenement supprim�");
					UpdateTable(table);
					
					
				} catch(SQLException e1) {
					e1.printStackTrace();
				}
			}
				
		}
		
		
	public  void UpdateTable(JTable table) {
			PreparedStatement pst=null;
			try {
				String sql="select * from evenement";
			    
				 pst = Connect.ConnectDb().prepareStatement(sql);
				 rs=pst.executeQuery();
				  table.setModel(DbUtils.resultSetToTableModel(rs));
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
	
	public  void UpdateTable2(JTable table) {
		PreparedStatement pst=null;
		try {
			String sql="select Nom,Description,Date_Debut,Date_Fin,Lieu from evenement order by Date_Debut";
		    
			 pst = Connect.ConnectDb().prepareStatement(sql);
			 rs=pst.executeQuery();
			  table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}


	public void reset(JTextField field) {
		// TODO Auto-generated method stub
	    field.setText(null); 
		
	}

	}
