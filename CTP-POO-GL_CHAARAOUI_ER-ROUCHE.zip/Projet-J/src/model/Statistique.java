package model;


public class Statistique {
	private int id;
	private String descriptif;
	private String somme;
	private String etat;
	
	public Statistique() {
		
	}
	
	public Statistique(int id, String descriptif,String somme,String etat) {
		this.id=id;
		this.descriptif=descriptif;
		this.somme=somme;
		this.etat=etat;
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDescriptif() {
		return descriptif;
	}

	public void setDescriptif(String descriptif) {
		this.descriptif = descriptif;
	}

	public String getSomme() {
		return somme;
	}

	public void setSomme(String somme) {
		this.somme = somme;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}
	
	@Override
	public String toString() {
		return String
				.format("statistique [id=%s, descriptif=%s, somme=%s, etat=%s]",
						id, descriptif, somme, etat);
	}
	

}
