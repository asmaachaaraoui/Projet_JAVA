package model;
import java.util.*;

public class Absence {
	
	private int id;
	private String nom;
	private String email;
	private Date date;
	private String raison;

	
	public Absence(int id, String Nom,String email, Date date,String Raison) {
		this.id = id;
		this.nom=nom;
		this.email= email;
		this.raison = raison;
		this.date=date;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	public Date getDate() {
		return date;
	}
	
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getRaison() {
		return raison;
	}

	public void setRaison(String raison) {
		this.raison= raison;
	}


	@Override
	public String toString() {
		return String
				.format("Absence [id=%s, nom=%s, raison=%s, date=%s]",
						id, nom, raison, date);
	}
	
	

}



