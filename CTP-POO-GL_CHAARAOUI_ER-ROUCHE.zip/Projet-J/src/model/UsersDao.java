package model;
/**
 * importer les packages.
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;


import view.MainnWindow;
import net.proteanit.sql.DbUtils;
import view.AdminWindow;
import view.UserWindow;
import model.Connect;
public class UsersDao {
	/**
	 * Declaration des variables Globales.
	 */
	
	    JTable table;
        JTextField field;
       String ad="administrateur";
	    Connect con;
		ResultSet rs;
		/**
		 * Methode pour la suppression des utilisateur.
		 */
	public void deleteUser(String email) throws SQLException {
		// create the DAO
				
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		try {
			// prepare statement
			pst = Connect.ConnectDb().prepareStatement("delete from utilisateur where email=?");
			pst1 = Connect.ConnectDb().prepareStatement("delete from absence where email=?");
			
			// set param
			pst.setString(1, email);
			pst1.setString(1, email);
			
			// execute SQL
			pst.executeUpdate();
			pst1.executeUpdate();
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
	}
	/**
	 * Methode pour la modification des utilisateur.
	 */
	public void updateUsers( String firstname, String lastname, String pass, String type,String login,String email ) throws SQLException {
		PreparedStatement myStmt = null;

		try {
			// prepare statement
			myStmt = Connect.ConnectDb().prepareStatement("update utilisateur set  firstname=?,lastname=?,pass=?, type=?, login=? where email=?");
			
			// set params
			myStmt.setString(1, firstname);
			myStmt.setString(2, lastname);
			myStmt.setString(3, pass);
			myStmt.setString(4, type);
			myStmt.setString(5, login);
			myStmt.setString(6, email);
			
		
			
			// execute SQL
			myStmt.executeUpdate();			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	
	
	}
	/**
	 * Methode pour ajouter des utilisateur.
	 */
	public void addUser(String firstname, String lastname,String email,String pass,String type,String login){
		PreparedStatement myStmt = null;

		try {
			
			// prepare statement
			myStmt = Connect.ConnectDb().prepareStatement("insert into utilisateur"
					+ " (firstname, lastname, email, pass,type,login)"
					+ " values (?, ?, ?, ?,?,?)");
			
			// set parametres
			myStmt.setString(1, firstname);
			myStmt.setString(2, lastname);
			myStmt.setString(3, email);
			myStmt.setString(4, pass);
			myStmt.setString(5, type);
			myStmt.setString(6, login);
			
			
			// execute SQL
			myStmt.executeUpdate();			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Methode pour remplir le JTable.
	 */
public  void UpdateTable(JTable table) {
		PreparedStatement pst=null;
		try {
			String sql="select * from utilisateur ";
		    
			 pst = Connect.ConnectDb().prepareStatement(sql);
			 rs=pst.executeQuery();
			  table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}


public void reset(JTextField field) {
		      field.setText("");   
		}

/**
 * Methode pour envoyer des avertissements d'absences.
 */
public void avert(JTable table,String email) {
	PreparedStatement pst= null;
	try {
		
		String sql="select Nom,  Date, raison from absence where email=? order by Date";
		 pst = Connect.ConnectDb().prepareStatement(sql);
		 pst.setString(1,email);
		 rs=pst.executeQuery();
		//nous donne la possibilites de remplir la table
		table.setModel(DbUtils.resultSetToTableModel(rs));
		if (table.getRowCount()>3) 
			JOptionPane.showMessageDialog(null," Vous avez d�pas� le nombre legal des absences, Malheureusement vous allez �tre sanctionn� ","ERROR" , JOptionPane.ERROR_MESSAGE);
	}catch(SQLException e) {
		e.printStackTrace();
	}
	
}

public void UpdateTable2(JTable table) {
	PreparedStatement pst=null;
	try {
		String sql="select firstname,lastname,email from utilisateur order by firstname,lastname";
		 con = new Connect();
		 pst = Connect.ConnectDb().prepareStatement(sql);
		 rs=pst.executeQuery();
		//nous donne la possibilites de remplir la table
		table.setModel(DbUtils.resultSetToTableModel(rs));
		
		
		
	}catch(SQLException e) {
		e.printStackTrace();
	}
}
/**
 * Methode qui assure le system login.
 */
public void Connection(String login, String pass) {
	PreparedStatement pst= null;
	
	
try {String query="SELECT * FROM `utilisateur` WHERE login=? and pass=? ";
pst = Connect.ConnectDb().prepareStatement(query);
pst.setString(1, login);
pst.setString(2,pass);
rs = pst.executeQuery();
if(rs.next()) {
	 
	JOptionPane.showMessageDialog(null,"login et mot de passe sont correct t'es connecter comme �tant un "+ rs.getString("type"));
	if (rs.getString("type").equals(ad)) {
    
	AdminWindow a =new AdminWindow();
	
	a.frame.setVisible(true);
	
	}else  {
		UserWindow u =new UserWindow();
		
		u.frame.setVisible(true);
		
		} 
  
}
else {
	JOptionPane.showMessageDialog(null,  "Les informations sont incorrect!!","Error", JOptionPane.ERROR_MESSAGE);
    }
}catch(SQLException e) {
	e.printStackTrace();
}

}
}

