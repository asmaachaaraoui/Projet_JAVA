package model;

/*
 * @auteurs CHAARAOUI/ER-ROUCHE
 */


import java.sql.*;



import java.util.*;
import javax.swing.*;
public class Connect{ 

 Connection conn=null;
 public static Connection ConnectDb() {
	 
	 try {
		 Class.forName("com.mysql.cj.jdbc.Driver");
		 Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/java?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","asmaa");
		 return conn; 
	 }catch(Exception e) {
		 JOptionPane.showMessageDialog(null, e);
		 return null;
	 }
	 
 }

	
	
	
	
}