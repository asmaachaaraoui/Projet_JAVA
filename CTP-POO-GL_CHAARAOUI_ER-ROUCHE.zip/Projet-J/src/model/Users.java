package model;

import java.math.BigDecimal;

public class Users {
	
	private int id;
	private String lastName;
	private String firstName;
	private String email;
	private String pass;
	private String login;
	private String type;
	

	public Users() {

	}
	
	public Users(int id, String lastName, String firstName, String email, String pass,String login,String type) {
		super();
		this.id = id;
		this.lastName = lastName;
		this.firstName = firstName;
		this.email = email;
		this.pass = pass;
		this.login = login;
		this.type = type;
		
		
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getPass() {
		return pass;
	}
	
	public void setPass(String pass) {
		this.pass = pass;
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type= type;
	}


	@Override
	public String toString() {
		return String
				.format("Employee [id=%s, lastName=%s, firstName=%s, email=%s]",
						id, lastName, firstName, email);
	}
	
	

}
