package model;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;



import model.Absence;
import view.GestionAbs;

import net.proteanit.sql.DbUtils;
import model.Connect;
public class AbsenceDao {
	    JTable table;
	  
        JTextField field;
	    Connect con;
		ResultSet rs;
	
	/**
	 * methode pour ajouter des absences.
	 */
	public void addAbsence(JTable table,String nom, String email,String date,String raison){
		PreparedStatement myStmt = null;

		try {
			
			// prepare statement
			myStmt = Connect.ConnectDb().prepareStatement("insert into absence"
					+ " (nom, email, date, raison)"
					+ " values (?, ?, ?, ?)");
			
			// set parametres
			myStmt.setString(1, nom);
			myStmt.setString(2, email);
			myStmt.setString(3, date);
			myStmt.setString(4, raison);
			
			
			
			// execute SQL
			myStmt.execute();
			JOptionPane.showMessageDialog(null, "Absence ajout�");
			UpdateTable(table);
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	/**
	 * Methode pour modifier des absences.
	 */
	public void updateAbs(  JTable table,String nom, String email,String date,String raison ) throws SQLException {
		PreparedStatement myStmt = null;

		try {
			int ligne =table.getSelectedRow();
			//System.out.println(ligne);
			if(ligne==-1) {
				JOptionPane.showMessageDialog(null, "S�lectionnez une absence");
			}
			else
			{
				String id=table.getModel().getValueAt(ligne,0).toString();
			// prepare statement
			myStmt = Connect.ConnectDb().prepareStatement("Update absence set Nom=?,Email=?,Date=?,Raison=? where ID_Absence='"+id+"'");
			
			// set params
			myStmt.setString(1, nom);
			myStmt.setString(2, email);
			myStmt.setString(3, date);
			myStmt.setString(4, raison);
			
		
			
			// execute SQL
			myStmt.executeUpdate();
			JOptionPane.showMessageDialog(null, "absence modifi�");
			UpdateTable(table);
			
			
			}		
		}catch(SQLException e) {
			e.printStackTrace();
		}
	
	
	}
	/**
	 * Methode pour supprimer des absences.
	 */
	public void deleteAbs(JTable table) {
		PreparedStatement myStmt=null;
		int ligne =table.getSelectedRow();
		if(ligne==-1) {
			JOptionPane.showMessageDialog(null, "S�lectionnez une absence");
		}
		else
		{
			String id=table.getModel().getValueAt(ligne,0).toString();
			try {
				myStmt = Connect.ConnectDb().prepareStatement("delete from absence where ID_Absence='"+id+"'");
				myStmt.executeUpdate();
			    JOptionPane.showMessageDialog(null, "absence supprim�");
				UpdateTable(table);
				
			} catch(SQLException e1) {
				e1.printStackTrace();
			}
			
		}
	}
	
	/**
	 * Methode pour remplir le JTable.
	 */
public  void UpdateTable(JTable table) {
		PreparedStatement pst=null;
		try {
			String sql="select * from absence";
			 pst = Connect.ConnectDb().prepareStatement(sql);
			 rs=pst.executeQuery();
			 table.setModel(DbUtils.resultSetToTableModel(rs));
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

/**
 * Methode pour le reset.
 */
public void reset(JComboBox comboBox) {
	// TODO Auto-generated method stub
    comboBox.setSelectedItem("S�lectionnez"); 
	
}


/*public void remplirCombobox(JComboBox combo){
	PreparedStatement myStmt=null;
	try {
		myStmt = Connect.ConnectDb().prepareStatement("select firstname, lastname from Utilisateur");
	    rs=myStmt.executeQuery();	
			String firstname =rs.getString("firstname").toString();
			String lastname =rs.getString("lastname").toString();
			combo.addItem(firstname+" "+lastname);
	
	}catch(SQLException e1) {
	e1.printStackTrace();
}
	
	
}

public void remplirCombobox2(JComboBox combo2){
	PreparedStatement myStmt=null;
	try {
		String sql="select email from Utilisateur";
		myStmt = Connect.ConnectDb().prepareStatement(sql);
	    rs=myStmt.executeQuery();
	    while(rs.next()) {
			String email =rs.getString("email").toString();
			System.out.println(email);
			combo2.addItem(email);
		
	}
	}catch(SQLException e1) {
	e1.printStackTrace();
}
	
	
}*/


}




