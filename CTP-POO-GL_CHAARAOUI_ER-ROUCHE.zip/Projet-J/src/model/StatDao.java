	package model;

	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;

	import javax.swing.JOptionPane;
	import javax.swing.JTable;
	import javax.swing.JTextField;



	import model.Users;
	import view.GestionUsers;

	import net.proteanit.sql.DbUtils;
	import model.Connect;
	public class StatDao {
		    JTable table;
	        JTextField field;
		    Connect con;
			ResultSet rs;
			/**
			 * Methode pour supprimer des statistiques.
			 */
		public void deleteDtat(JTable table) throws SQLException {
			// create the DAO
					
			PreparedStatement pst = null;
			int ligne =table.getSelectedRow();
			if(ligne==-1) {
				JOptionPane.showMessageDialog(null, "S�lectionnez une ligne");
			}
			else
			{
				String id=table.getModel().getValueAt(ligne,0).toString();
				String sql="delete from statistique where ID_stat='"+id+"'";
			
				try {
					
					 pst = Connect.ConnectDb().prepareStatement(sql);
					pst.execute();
					JOptionPane.showMessageDialog(null, "suppression bien effectuee");
					UpdateTable(table);
					
				} catch(SQLException e1) {
					e1.printStackTrace();
				}
			}	
			
		}
		/**
		 * Methode pour modifier des statistiques.
		 */
		public void updateStat( JTable table, String Nom,String Descriptif, String Somme,String etat ) throws SQLException {
			PreparedStatement myStmt = null;
			int ligne =table.getSelectedRow();
			 if(ligne==-1) {
					JOptionPane.showMessageDialog(null, "S�lectionnez une ligne");
				}
				else
				{
					String id=table.getModel().getValueAt(ligne,0).toString();
					//System.out.println(id);
					String sql="Update statistique set Nom=?, Description=?,Somme=?, Etat=? where ID_stat='"+id+"'";
					try {
              myStmt = Connect.ConnectDb().prepareStatement(sql);
						myStmt.setString(2, Descriptif);
						myStmt.setString(1, Nom);
						myStmt.setString(3, Somme);
						myStmt.setString(4, etat);
						myStmt.execute();
						JOptionPane.showMessageDialog(null, "modification bien effectu�e");
						UpdateTable(table);
						
					} catch(SQLException e1) {
						e1.printStackTrace();
					}
		}
		
		}
		/**
		 * Methode pour Ajouter des statistiques.
		 */
		public void addStat(JTable table, String nom,String descriptif,String somme,String etat){
			PreparedStatement myStmt = null;
			try {
				
				// prepare statement
				myStmt = Connect.ConnectDb().prepareStatement("insert into statistique(Nom,Description,Somme,Etat) values(?,?,?,?)");
				
				// set parametres
				myStmt.setString(1,nom);
				myStmt.setString(2,descriptif);
				myStmt.setString(3, somme);
				myStmt.setString(4, etat);	
				// execute SQL
				myStmt.executeUpdate();	
				JOptionPane.showMessageDialog(null, "ajout bien effectu�e");
				UpdateTable(table);
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
		
	public  void UpdateTable(JTable table) {
			PreparedStatement pst=null;
			try {
				String sql="select * from statistique";
			    
				 pst = Connect.ConnectDb().prepareStatement(sql);
				 rs=pst.executeQuery();
				  table.setModel(DbUtils.resultSetToTableModel(rs));
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}

public void UpdateTable2(JTable table) {
		PreparedStatement pst=null;
		try {
			String sql="select Nom,Description, Somme, Etat from statistique order by Somme DESC ";
			 con = new Connect();
			 pst = Connect.ConnectDb().prepareStatement(sql);
			 rs=pst.executeQuery();
			
			table.setModel(DbUtils.resultSetToTableModel(rs));
			
			
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}

	public void reset(JTextField field) {
			      field.setText(null);   
			}
	}



