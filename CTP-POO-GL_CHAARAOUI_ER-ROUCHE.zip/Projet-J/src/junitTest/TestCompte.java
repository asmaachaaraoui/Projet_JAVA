package junitTest;


import org.junit.jupiter.api.Test;

import junit.framework.TestCase;


class TestCompte extends TestCase {
	 Compte compte1;
	 
	
	public void mesInitialisations() {
		compte1=new Compte("ahmed","ahmed123");
	}

	@Test
	void test() {
		this.mesInitialisations();
		Compte expected=new Compte("ahmed","ahmed123");
		try{
			boolean result = expected.equals(compte1);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

}
