package junitTest;

public class Compte {
	private String login;
	private String pass;
	public Compte (String login, String pass) {
		
		this.login=login;
		this.pass=pass;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	@Override
	public String toString() {
		return "Compte [login=" + login + ", pass=" + pass + "]";
	}
	public boolean equals(Object anObject) {
		if(anObject==null) 			
			return false;
		
		if (anObject instanceof Compte) {
			Compte cpt=(Compte)anObject;
			return cpt.getPass().equals(getPass())&&getLogin()== cpt.getLogin();
		}
		return false;
	}
}
