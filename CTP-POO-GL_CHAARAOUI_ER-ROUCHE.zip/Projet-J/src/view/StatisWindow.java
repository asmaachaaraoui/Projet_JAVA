package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Container;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import model.AbsenceDao;
import model.Connect;
import net.proteanit.sql.DbUtils;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import model.StatDao;
public class StatisWindow {
    private StatDao stat;
	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JComboBox comboBox;
	
	private JPanel contentPane;
	private JTable table_1;
	Connect con;
	PreparedStatement pst;
	ResultSet rs;
	private JTextField textField_2;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StatisWindow window = new StatisWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StatisWindow() {
		initialize();
		try {
			stat = new StatDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
	
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 677, 390);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(32, 178, 170));
		panel.setBounds(0, 0, 661, 59);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblStatistiques = new JLabel("Statistiques");
		lblStatistiques.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 25));
		lblStatistiques.setBounds(263, 11, 196, 26);
		panel.add(lblStatistiques);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				AdminWindow aw=new AdminWindow();
				aw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo3=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		label.setIcon(new ImageIcon(photo3));

		label.setBounds(10, 11, 46, 37);
		panel.add(label);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 61, 661, 291);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(102, 205, 170));
		panel_2.setBounds(10, 11, 252, 269);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Descriptif");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel.setBounds(10, 99, 75, 17);
		panel_2.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Somme");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(10, 142, 75, 14);
		panel_2.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Type");
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(10, 173, 75, 17);
		panel_2.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(79, 98, 163, 20);
		panel_2.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(79, 140, 163, 20);
		panel_2.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textField.setText(null);
				textField_1.setText(null);
				textField_2.setText(null);
				comboBox.setSelectedItem("S�lectionnez");
			}
		});
		btnReset.setBounds(76, 246, 89, 23);
		panel_2.add(btnReset);
		
		JLabel lblVeuillezSaisirLes = new JLabel("Veuillez Saisir les Informations suivantes:");
		lblVeuillezSaisirLes.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblVeuillezSaisirLes.setBounds(10, 11, 232, 14);
		panel_2.add(lblVeuillezSaisirLes);
		
		 comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"S\u00E9lectionnez", "Ajout", "D\u00E9pense "}));
		comboBox.setBounds(79, 172, 163, 20);
		panel_2.add(comboBox);
		
		JLabel lblNom = new JLabel("Nom:");
		lblNom.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNom.setBounds(10, 58, 46, 14);
		panel_2.add(lblNom);
		
		textField_2 = new JTextField();
		textField_2.setBounds(79, 57, 163, 20);
		panel_2.add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nom=textField_2.getText().toString();
				String Descriptif=textField.getText().toString();
				String Somme=textField_1.getText().toString();
				String type=comboBox.getSelectedItem().toString();

				if(!comboBox.getSelectedItem().equals("S�lectionnez") && !nom.equals("") && !Descriptif.equals("") && !Somme.equals("")){
			     stat.addStat(table_1,nom,Descriptif, Somme, type);	
			     stat.reset(textField);
			     stat.reset(textField_2);
			     stat.reset(textField_1);
				}
				else
					JOptionPane.showMessageDialog(null, "Veuillez remplir tout les champs");
						
	    }			
		});
		btnSave.setBounds(285, 244, 89, 23);
		panel_1.add(btnSave);
		
		JButton btnModifier = new JButton("Modifier");
		btnModifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String Descriptif=textField.getText().toString();
				String Nom=textField_2.getText().toString();
				String Somme=textField_1.getText().toString();
				String etat= comboBox.getSelectedItem().toString();
				try {
					stat.updateStat(table_1, Descriptif, Nom,Somme, etat);
					stat.reset(textField);
					stat.reset(textField_2);
					stat.reset(textField_1);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		});
		btnModifier.setBounds(396, 244, 89, 23);
		panel_1.add(btnModifier);
		
		JButton btnNewButton = new JButton("Supprimer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					stat.deleteDtat(table_1);
					stat.reset(textField);
					stat.reset(textField_2);
					stat.reset(textField_1);
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		btnNewButton.setBounds(510, 244, 129, 23);
		panel_1.add(btnNewButton);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				stat.UpdateTable(table_1);
			}
		});
		Image photo=new ImageIcon(this.getClass().getResource("/Repeat-3-2-icon.png")).getImage();
		label_1.setIcon(new ImageIcon(photo));
		
		label_1.setBounds(593, 0, 46, 36);
		panel_1.add(label_1);
		
		JLabel lblLesDifferentesInformations = new JLabel("Les Differentes informations sur les statistiques:");
		lblLesDifferentesInformations.setBounds(272, 11, 294, 14);
		panel_1.add(lblLesDifferentesInformations);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(282, 36, 369, 180);
		panel_1.add(scrollPane_2);
		
		table_1 = new JTable();
		table_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				int ligne=table_1.getSelectedRow();
        		//JOptionPane.showMessageDialog(null, ligne);
				String Nom=table_1.getModel().getValueAt(ligne,1).toString();
        		String Descriptif=table_1.getModel().getValueAt(ligne,2).toString();
        		String Somme=table_1.getModel().getValueAt(ligne,3).toString();
        		textField_2.setText(Nom);
        		textField.setText(Descriptif);
        		textField_1.setText(Somme);
			}
        		
		});
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
				{null, null, null, null, null},
			},
			new String[] {
				"ID_stat", "Nom","Descriptif", "Somme", "Type"
			}
		));
		scrollPane_2.setViewportView(table_1);
		scrollPane_2.add(table_1);
        scrollPane_2.setViewportView(table_1);
		
		
		
		
	}
}