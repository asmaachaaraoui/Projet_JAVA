package view;
import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuItem;
import javax.swing.JLabel;

import javax.swing.JButton;

import javax.swing.JMenuBar;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JMenu;
import java.awt.Color;

import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


public class AdminWindow {

	public JFrame frame;
	protected UserWindow a;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminWindow window = new AdminWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 581, 464);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 575, 426);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 140, 0));
		panel_2.setBounds(0, 21, 565, 74);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblSystemeDeMagnagement = new JLabel("Systeme De Gestion De Club");
		lblSystemeDeMagnagement.setBounds(146, 22, 272, 27);
		lblSystemeDeMagnagement.setLabelFor(frame);
		lblSystemeDeMagnagement.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 23));
		panel_2.add(lblSystemeDeMagnagement);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(116,1227, 127, 114);
		panel.add(panel_3);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(116 ,1297 ,127 ,114);
		panel.add(panel_4);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(412, 116, 127, 114);
		panel.add(panel_5);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Bureau br= new Bureau();
				br.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		
		
		Image photo=new ImageIcon(this.getClass().getResource("/Groups-Meeting-Dark-icon.png")).getImage();
		btnNewButton_4.setIcon(new ImageIcon(photo));
		
		
		panel_5.add(btnNewButton_4);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBounds(30, 276, 127, 114);
		panel.add(panel_6);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StatisWindow sw = new StatisWindow();
				sw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo1=new ImageIcon(this.getClass().getResource("/Statistiques-icon.png")).getImage();
		btnNewButton_1.setIcon(new ImageIcon(photo1));
		
		panel_6.add(btnNewButton_1);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBounds(276, 2627, 127, 114);
		panel.add(panel_7);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBounds(276,2527,127,114);
		panel.add(panel_8);
		
		JLabel lblStatistiques = new JLabel("Statistiques");
		lblStatistiques.setBounds(57, 390, 73, 14);
		panel.add(lblStatistiques);
		
		JPanel panel_9 = new JPanel();
		panel_9.setBounds(30, 116, 127, 114);
		panel.add(panel_9);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {		
			GestionUsers u1= new GestionUsers();
			u1.setVisible(true);
			frame.setVisible(false);
			}
		});
		Image photo2=new ImageIcon(this.getClass().getResource("/Actions-user-properties-icon.png")).getImage();
		btnNewButton.setIcon(new ImageIcon(photo2));
		panel_9.add(btnNewButton);
		
		JPanel panel_10 = new JPanel();
		panel_10.setBounds(219, 116, 127, 114);
		panel.add(panel_10);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				GestionAbs ga=new GestionAbs();
        		ga.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo3=new ImageIcon(this.getClass().getResource("/Male-user-accept-icon.png")).getImage();
		btnNewButton_3.setIcon(new ImageIcon(photo3));
		panel_10.add(btnNewButton_3);
		
		JPanel panel_11 = new JPanel();
		panel_11.setBounds(219, 276, 127, 114);
		panel.add(panel_11);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				EvenementWin event =new EvenementWin();
				event.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo4=new ImageIcon(this.getClass().getResource("/Calendar-icon.png")).getImage();
		btnNewButton_2.setIcon(new ImageIcon(photo4));
		panel_11.add(btnNewButton_2);
		
		JLabel lblGestionUtilisateur = new JLabel("Gestion Utilisateur");
		lblGestionUtilisateur.setBounds(40, 233, 127, 14);
		panel.add(lblGestionUtilisateur);
		
		JLabel lblGestionAbscences = new JLabel("Gestion Abscences");
		lblGestionAbscences.setBounds(229, 233, 112, 14);
		panel.add(lblGestionAbscences);
		
		JLabel lblExit = new JLabel("Deconnection");
		lblExit.setBounds(436, 390, 103, 14);
		panel.add(lblExit);
		
		JLabel lblRapports = new JLabel("Gestion Evenements");
		lblRapports.setBounds(229, 390, 149, 14);
		panel.add(lblRapports);
		
		JLabel lblBureau = new JLabel("Bureau");
		lblBureau.setBounds(465, 233, 46, 14);
		panel.add(lblBureau);
		
		JPanel panel_12 = new JPanel();
		panel_12.setBounds(412, 276, 127, 114);
		panel.add(panel_12);
		
		JButton btnNewButton_6 = new JButton("");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainnWindow mw=new MainnWindow();
				mw.frame.setVisible(true);
				frame.setVisible(false);
				
			}
		});
		panel_12.add(btnNewButton_6);
		Image photo5=new ImageIcon(this.getClass().getResource("/Actions-application-exit-icon.png")).getImage();
		btnNewButton_6.setIcon(new ImageIcon(photo5));
		
	}
	
	

	public void setVisible(boolean b) {
		// TODO Auto-generated method stub
		
	}
}
