package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JEditorPane;
import javax.swing.JComboBox;
import com.toedter.calendar.JDateChooser;

import model.Absence;
import model.AbsenceDao;
import model.Connect;
import net.proteanit.sql.DbUtils;

import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class GestionAbs {
	 AbsenceDao absence;
	 JFrame frame;
	 private JComboBox NomMemBox;
	 private JComboBox comboBox;
	 private JComboBox comboBox_1;
	 private JDateChooser dateChooser;
	 JTable table;
	 private Connect con;
	 private PreparedStatement pst;
	 private ResultSet rs;
	 private Absence abs;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionAbs window = new GestionAbs();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public GestionAbs() {
		initialize();
		try {
			absence = new AbsenceDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		

		frame = new JFrame();
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(240, 240, 240));
		frame.setBounds(100, 100, 774, 389);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 21, 133));
		panel.setBounds(0, 11, 768, 66);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblGestionDesAbscences = new JLabel("Gestion Des Abscences");
		lblGestionDesAbscences.setBackground(new Color(240, 240, 240));
		lblGestionDesAbscences.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblGestionDesAbscences.setBounds(274, 11, 299, 34);
		panel.add(lblGestionDesAbscences);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminWindow aw=new AdminWindow();
				aw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		label.setIcon(new ImageIcon(photo));
		label.setBounds(10, 11, 47, 34);
		panel.add(label);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 240, 245));
		panel_1.setBounds(10, 90, 275, 265);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNomDuMembre = new JLabel("Nom Du Membre :");
		lblNomDuMembre.setBounds(10, 62, 100, 14);
		panel_1.add(lblNomDuMembre);
		
		JLabel lblDateDabscence = new JLabel("Date D'abscence :");
		lblDateDabscence.setBounds(10, 149, 112, 14);
		panel_1.add(lblDateDabscence);
		
		JLabel lblRaisonDabscence = new JLabel("Raison  :");
		lblRaisonDabscence.setBounds(10, 195, 83, 14);
		panel_1.add(lblRaisonDabscence);
		
		NomMemBox = new JComboBox();
		NomMemBox.setModel(new DefaultComboBoxModel(new String[] {"S\u00E9lectionnez"}));
		NomMemBox.setBounds(120, 59, 124, 20);
		panel_1.add(NomMemBox);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("yyyy-MM-d\r\n");
		dateChooser.setBounds(120, 143, 124, 20);
		panel_1.add(dateChooser);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"S\u00E9lectionnez", "Maladie.", "Retard.", "Engagement Educatif."}));
		comboBox.setBounds(120, 192, 124, 20);
		panel_1.add(comboBox);
		
		JLabel lblNewLabel = new JLabel("Veuillez Remplir les champs suivants : ");
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel.setBounds(10, 23, 218, 14);
		panel_1.add(lblNewLabel);
		
		JLabel lblEmail = new JLabel("Email:");
		lblEmail.setBounds(10, 108, 65, 14);
		panel_1.add(lblEmail);
		
		 comboBox_1 = new JComboBox();
		comboBox_1.setBounds(120, 102, 124, 20);
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"S\u00E9lectionnez"}));
		panel_1.add(comboBox_1);
		
		remplirCombobox();
		
		
		JButton btnSave = new JButton("Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
			    try {
			    String nom=NomMemBox.getSelectedItem().toString();
				String email=comboBox_1.getSelectedItem().toString();
				String date = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
			    String raison= comboBox.getSelectedItem().toString();
       			 
       			 if(!comboBox.getSelectedItem().equals("S�lectionnez") && !comboBox_1.getSelectedItem().equals("S�lectionnez") && 
       					!NomMemBox.getSelectedItem().equals("S�lectionnez")) 
       			 {
       			    absence.addAbsence(table,nom,email,date,raison);
       		
       			      absence.reset(comboBox);
       			      absence.reset(comboBox_1);
       			      absence.reset(NomMemBox);
       			 } 
       			 else {
       			  JOptionPane.showMessageDialog(null, "Veuillez Inserer tout les champs","ERROR",JOptionPane.ERROR_MESSAGE);
       			 }
       		 }
       		 catch(Exception ex) {
       			ex.printStackTrace();}
			}});
       		 
		btnSave.setBackground(new Color(230, 230, 250));
		Image photo1=new ImageIcon(this.getClass().getResource("/Male-user-accept-icon (1).png")).getImage();
		btnSave.setIcon(new ImageIcon(photo1));
		
		btnSave.setBounds(295, 294, 122, 61);
		frame.getContentPane().add(btnSave);
		
		JButton btnModifeier = new JButton("Modifier");
		btnModifeier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String nom=NomMemBox.getSelectedItem().toString();
				 String email= comboBox_1.getSelectedItem().toString();
				String date = ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
			    String raison= comboBox.getSelectedItem().toString();
				try {
					absence.updateAbs(table,nom, email, date, raison);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
						absence.reset(comboBox);
						absence.reset(comboBox_1);
						absence.reset(NomMemBox);	
			}
			
		});
		btnModifeier.setBackground(new Color(230, 230, 250));
		Image photo2=new ImageIcon(this.getClass().getResource("/Male-user-edit-icon.png")).getImage();
		btnModifeier.setIcon(new ImageIcon(photo2));
		btnModifeier.setBounds(427, 294, 138, 61);
		frame.getContentPane().add(btnModifeier);
		
		JButton btnNewButton = new JButton("Supprimer");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				absence.deleteAbs(table);
			}
		});
		btnNewButton.setBackground(new Color(230, 230, 250));
		Image photo3=new ImageIcon(this.getClass().getResource("/Male-user-warning-icon.png")).getImage();
		btnNewButton.setIcon(new ImageIcon(photo3));
		
		btnNewButton.setBounds(575, 294, 155, 61);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblTableDesAbscents = new JLabel("Table Des Abscents:");
		lblTableDesAbscents.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblTableDesAbscents.setBounds(298, 88, 149, 14);
		frame.getContentPane().add(lblTableDesAbscents);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				absence.UpdateTable(table);
			}
		});
		Image photo4=new ImageIcon(this.getClass().getResource("/Repeat-3-2-icon.png")).getImage();
		label_1.setIcon(new ImageIcon(photo4));
		
	
		label_1.setBounds(706, 75, 52, 38);
		frame.getContentPane().add(label_1);
		
		JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(303, 112, 455, 171);
        frame.getContentPane().add(scrollPane);
        
        table=new JTable(new DefaultTableModel(
        	new Object[][] {
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        		{null, null, null, null,null},
        	},
        	new String[] {
        		"Id_Absence", "Nom","E-mail", "Date", "Raison",
        	}
        ));
    
		
		scrollPane.setViewportView(table);
		table.setVisible(true);
	}
	
	public void remplirCombobox(){
		String sql="select firstname, lastname,email from Utilisateur";
		try {
			con = new Connect();
			 pst = Connect.ConnectDb().prepareStatement(sql);
			ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				String email =rs.getString("email").toString();
				String firstname =rs.getString("firstname").toString();
				String lastname =rs.getString("lastname").toString();
				NomMemBox.addItem(firstname+" "+lastname);
				comboBox_1.addItem(email);
			}
				 
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	}
