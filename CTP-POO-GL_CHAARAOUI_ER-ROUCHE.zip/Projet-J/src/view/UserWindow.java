package view;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JMenuBar;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class UserWindow {

	 public JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserWindow window = new UserWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 572, 429);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 566, 401);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 140, 0));
		panel_2.setBounds(0, 21, 569, 58);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblSystemeDeGestion = new JLabel("Systeme De Gestion De Club");
		lblSystemeDeGestion.setBounds(148, 11, 272, 27);
		lblSystemeDeGestion.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 23));
		panel_2.add(lblSystemeDeGestion);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(45, 108, 127, 114);
		panel.add(panel_3);
		
		JButton btnNewButton_1 = new JButton("");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MembreWin mw=new MembreWin();
				mw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo=new ImageIcon(this.getClass().getResource("/User-Group-icon (1).png")).getImage();
		btnNewButton_1.setIcon(new ImageIcon(photo));
		
		panel_3.add(btnNewButton_1);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBounds(219, 108, 127, 114);
		panel.add(panel_4);
		
		JButton btnNewButton_2 = new JButton("");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserAbsence ua =new UserAbsence();
				ua.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo1=new ImageIcon(this.getClass().getResource("/Male-user-accept-icon.png")).getImage();
		btnNewButton_2.setIcon(new ImageIcon(photo1));
		
		panel_4.add(btnNewButton_2);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBounds(389, 108, 127, 114);
		panel.add(panel_5);
		
		JButton btnNewButton_5 = new JButton("");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserBureau window = new UserBureau();
				window.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo3=new ImageIcon(this.getClass().getResource("/Groups-Meeting-Dark-icon.png")).getImage();
		btnNewButton_5.setIcon(new ImageIcon(photo3));
		
		panel_5.add(btnNewButton_5);
		
		JPanel panel_6 = new JPanel();
		panel_6.setBounds(45, 247, 127, 114);
		panel.add(panel_6);
		
		JButton btnNewButton_3 = new JButton("");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserStat ys = new UserStat();
				ys.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo2=new ImageIcon(this.getClass().getResource("/Statistiques-icon.png")).getImage();
		btnNewButton_3.setIcon(new ImageIcon(photo2));
		
		panel_6.add(btnNewButton_3);
		
		JPanel panel_7 = new JPanel();
		panel_7.setBounds(219, 247, 127, 114);
		panel.add(panel_7);
		
		JButton btnNewButton_4 = new JButton("");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UserEvent ue=new UserEvent();
				ue.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo4=new ImageIcon(this.getClass().getResource("/Calendar-icon (1).png")).getImage();
		btnNewButton_4.setIcon(new ImageIcon(photo4));
		
		panel_7.add(btnNewButton_4);
		
		JPanel panel_8 = new JPanel();
		panel_8.setBounds(389, 247, 127, 114);
		panel.add(panel_8);
		
		JButton btnNewButton_6 = new JButton("");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				MainnWindow mw=new MainnWindow();
				mw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo6=new ImageIcon(this.getClass().getResource("/Actions-application-exit-icon.png")).getImage();
		btnNewButton_6.setIcon(new ImageIcon(photo6));
	
		panel_8.add(btnNewButton_6);
		
		JLabel lblMembres = new JLabel("Membres");
		lblMembres.setBounds(67, 222, 79, 14);
		panel.add(lblMembres);
		
		JLabel lblStatistiques = new JLabel("Statistiques");
		lblStatistiques.setBounds(66, 364, 91, 14);
		panel.add(lblStatistiques);
		
		JLabel lblAbscences = new JLabel("Abscences");
		lblAbscences.setBounds(251, 222, 95, 14);
		panel.add(lblAbscences);
		
		JLabel lblBureau = new JLabel("Bureau");
		lblBureau.setBounds(441, 222, 46, 14);
		panel.add(lblBureau);
		
		JLabel lblEvenements = new JLabel("Evenements");
		lblEvenements.setBounds(251, 364, 95, 14);
		panel.add(lblEvenements);
		
		JLabel lblExit = new JLabel("EXIT");
		lblExit.setBounds(441, 364, 46, 14);
		panel.add(lblExit);
	}
	
}
