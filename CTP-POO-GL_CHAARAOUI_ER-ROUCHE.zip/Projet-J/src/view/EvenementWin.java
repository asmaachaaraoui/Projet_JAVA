package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.toedter.components.JSpinField;

import model.AbsenceDao;
import model.Connect;
import net.proteanit.sql.DbUtils;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import model.EventDao;
public class EvenementWin {
    EventDao event;
	JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTable table;
	Connect con;
	PreparedStatement pst;
	ResultSet rs;
  
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EvenementWin window = new EvenementWin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EvenementWin() {
		try {
			event = new EventDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
	
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 880, 388);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(205, 92, 92));
		panel.setBounds(0, 0, 864, 60);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblGestionDesEvnements = new JLabel("Gestion Des Ev\u00E9nements");
		lblGestionDesEvnements.setBounds(268, 11, 272, 27);
		lblGestionDesEvnements.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 23));
		panel.add(lblGestionDesEvnements);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
				AdminWindow a=new AdminWindow();
        		a.frame.setVisible(true);
        		frame.setVisible(false);
			}
		});
		Image photo=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		label_1.setIcon(new ImageIcon(photo));
		label_1.setBounds(10, 11, 46, 38);
		panel.add(label_1);
		
		JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(356, 104, 508, 171);
        frame.getContentPane().add(scrollPane);
        
        table=new JTable(new DefaultTableModel(
        	new Object[][] {
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        		{null, null, null, null, null, null},
        	},
        	new String[] {
        		"ID_event", "Nom", "Description", "Date_D\u00E9but", "Date_Fin", "Lieu"
        	}
        ));
        table.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        		int ligne=table.getSelectedRow();
        		//JOptionPane.showMessageDialog(null, ligne);
				String Nom=table.getModel().getValueAt(ligne,1).toString();
        		String Descriptif=table.getModel().getValueAt(ligne,2).toString();
        		String Lieu=table.getModel().getValueAt(ligne,5).toString();
        		textField.setText(Nom);
        		textField_1.setText(Descriptif);
        		textField_2.setText(Lieu);
        	}
        });
       
        scrollPane.add(table);
        scrollPane.setViewportView(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 61, 864, 289);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(233, 150, 122));
		panel_2.setBounds(10, 11, 329, 267);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblVeuillezRemplirLes = new JLabel("Veuillez remplir les champs suivants:");
		lblVeuillezRemplirLes.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblVeuillezRemplirLes.setBounds(10, 11, 269, 14);
		panel_2.add(lblVeuillezRemplirLes);
		
		JLabel lblNewLabel = new JLabel("Nom:");
		lblNewLabel.setBounds(20, 45, 46, 14);
		panel_2.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Description");
		lblNewLabel_1.setBounds(20, 91, 89, 14);
		panel_2.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Date Debut");
		lblNewLabel_2.setBounds(20, 132, 89, 14);
		panel_2.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Date Fin");
		lblNewLabel_3.setBounds(20, 172, 46, 14);
		panel_2.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Lieu");
		lblNewLabel_4.setBounds(20, 213, 46, 14);
		panel_2.add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("Reset");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				event.reset(textField);
				event.reset(textField_1);
				event.reset(textField_2);
			
			}
		});
		btnNewButton.setBounds(84, 241, 98, 23);
		panel_2.add(btnNewButton);
		
		textField = new JTextField();
		textField.setBounds(119, 42, 170, 20);
		panel_2.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(119, 88, 170, 20);
		panel_2.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(119, 210, 170, 20);
		panel_2.add(textField_2);
		textField_2.setColumns(10);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setDateFormatString("yyyy-MM-d");
		dateChooser.setBounds(118, 126, 171, 20);
		panel_2.add(dateChooser);
		
		JDateChooser dateChooser_1 = new JDateChooser();
		dateChooser_1.setDateFormatString("yyyy-MM-d");
		dateChooser_1.setBounds(119, 166, 171, 20);
		panel_2.add(dateChooser_1);
		
		JLabel lblListeDesEvnements = new JLabel("Liste Des Ev\u00E9nements et Des R\u00E9unions:");
		lblListeDesEvnements.setBounds(355, 11, 251, 14);
		panel_1.add(lblListeDesEvnements);
		
		JLabel label = new JLabel("");
		label.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				event.UpdateTable(table);
			}
		});
		
		Image photo1=new ImageIcon(this.getClass().getResource("/Repeat-3-2-icon.png")).getImage();
		label.setIcon(new ImageIcon(photo1));
		label.setBounds(808, 0, 46, 46);
		panel_1.add(label);
		
		JButton btnNewButton_1 = new JButton("Save");
		btnNewButton_1.setBackground(new Color(144, 238, 144));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String nom=textField.getText().toString();
				String Description=textField_1.getText().toString();
				String DateDebut= ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
				String DateFin= ((JTextField) dateChooser_1.getDateEditor().getUiComponent()).getText();
				String Lieu=textField_2.getText().toString();
		 
						if(!nom.equals("") && !DateDebut.equals("") &&!DateFin.equals("") && !Description.equals("")&& !Lieu.equals("")) {
							event.addEvent(table,nom, Description, DateDebut, DateFin, Lieu);
							event.reset(textField);
							event.reset(textField_1);
							event.reset(textField_2);
							
							
						}
						else
							JOptionPane.showMessageDialog(null, "Veuillez remplir tout les champs");

			}
		});
		btnNewButton_1.setBounds(396, 233, 89, 45);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Modifier");
		btnNewButton_2.setBackground(new Color(204, 204, 204));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String nom=textField.getText().toString();
				String Description=textField_1.getText().toString();
				String DateDebut= ((JTextField) dateChooser.getDateEditor().getUiComponent()).getText();
				String DateFin= ((JTextField) dateChooser_1.getDateEditor().getUiComponent()).getText();
				String Lieu=textField_2.getText().toString();
				
						if(!nom.equals("") && !DateDebut.equals("") &&!DateFin.equals("") && !Description.equals("")&& !Lieu.equals(""))
						{
							try {
								event.updateEvent(table, nom, Description, DateDebut, DateFin, Lieu);
								event.reset(textField);
								event.reset(textField_1);
								event.reset(textField_2);
							} catch (SQLException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						
						}else 
							JOptionPane.showMessageDialog(null, "Veuillez remplir tout les champs");
					}	
		});
		
		btnNewButton_2.setBounds(537, 233, 106, 45);
		panel_1.add(btnNewButton_2);
		
		JButton btnSupprimer = new JButton("Supprimer");
		btnSupprimer.setBackground(new Color(250, 128, 114));
		btnSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				event.deleteEvent(table);
			}
		});
		btnSupprimer.setBounds(686, 233, 112, 45);
		panel_1.add(btnSupprimer);
	}
}
