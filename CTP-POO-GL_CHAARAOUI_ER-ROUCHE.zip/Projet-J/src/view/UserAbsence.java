package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Connect;
import model.UsersDao;
import net.proteanit.sql.DbUtils;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import model.UsersDao;
public class UserAbsence {

	JFrame frame;
	UsersDao userDao;
	private JTable table;
	 Connect con;
	PreparedStatement pst;
	ResultSet rs;
	JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserAbsence window = new UserAbsence();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserAbsence() {
		initialize();
		try {
			userDao = new UsersDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 566, 369);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(221, 160, 221));
		panel.setBounds(0, 0, 557, 61);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Absences");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(240, 11, 228, 37);
		panel.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				UserWindow uw=new UserWindow();
				uw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo3=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		label_1.setIcon(new ImageIcon(photo3));
	
		label_1.setBounds(0, 11, 46, 37);
		panel.add(label_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 70, 540, 250);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(30, 84, 495, 155);
		panel_1.add(scrollPane_2);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
				{null, null, null},
			},
			new String[] {
				 "Nom", "Date", "Raison"
			}
		));
		scrollPane_2.setViewportView(table);
		scrollPane_2.add(table);
        scrollPane_2.setViewportView(table);
        
        
        JLabel lblLesDiffrentsMembre = new JLabel(" Absence  :");
        lblLesDiffrentsMembre.setBounds(30, 59, 244, 14);
        panel_1.add(lblLesDiffrentsMembre);
        
        JLabel lblVeuillezEntrerVotre = new JLabel("Veuillez entrer Votre E-mail:");
        lblVeuillezEntrerVotre.setBounds(30, 11, 181, 14);
        panel_1.add(lblVeuillezEntrerVotre);
        
        textField = new JTextField();
        textField.setBounds(201, 8, 181, 20);
        panel_1.add(textField);
        textField.setColumns(10);
        
        JButton btnRecherche = new JButton("Recherche");
        btnRecherche.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		if(textField.getText().equals("")) {
        			JOptionPane.showMessageDialog(null," veuillez remplir le champs e-mail");}
        		else {	String email=textField.getText().toString();
        		 userDao.avert(table,email);
        	}
        	}
        });
        btnRecherche.setBackground(new Color(230, 230, 250));
        btnRecherche.setBounds(413, 7, 112, 23);
        panel_1.add(btnRecherche);
		
		

	}
	
	
   
}