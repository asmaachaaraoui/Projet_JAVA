package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import model.Connect;
import net.proteanit.sql.DbUtils;
import model.EventDao;
public class UserEvent {

	JFrame frame;
    EventDao event;	
	private JTable table;
	 Connect con;
	PreparedStatement pst;
	ResultSet rs;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UserEvent window = new UserEvent();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public UserEvent() {
		initialize();
		try {
			event = new EventDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 573, 319);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(154, 205, 50));
		panel.setBounds(0, 0, 567, 61);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Evenement");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(240, 11, 228, 37);
		panel.add(lblNewLabel);
		
		JLabel label_1 = new JLabel("");
		label_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				UserWindow uw=new UserWindow();
				uw.frame.setVisible(true);
				frame.setVisible(false);
			}
		});
		Image photo3=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		label_1.setIcon(new ImageIcon(photo3));
	
		label_1.setBounds(0, 11, 46, 37);
		panel.add(label_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 70, 589, 243);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(30, 41, 495, 155);
		panel_1.add(scrollPane_2);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				
			}
		});
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
				{null, null, null,null,null},
			},
			new String[] {
				 "Nom", "Description", "Date_Debut","Date_Fin","Lieu"
			}
		));
		scrollPane_2.setViewportView(table);
		scrollPane_2.add(table);
        scrollPane_2.setViewportView(table);
        //event.UpdateTable2(table);
        
        JLabel lblLesDiffrentsMembre = new JLabel(" Evenements & r�unions  :");
        lblLesDiffrentsMembre.setBounds(30, 8, 244, 14);
        panel_1.add(lblLesDiffrentsMembre);
        
        JLabel label = new JLabel("");
        label.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        		event.UpdateTable2(table);
        		
        	}
        });
        Image photo=new ImageIcon(this.getClass().getResource("/Repeat-3-2-icon.png")).getImage();
		label.setIcon(new ImageIcon(photo));
        
        label.setBounds(449, 0, 46, 32);
        panel_1.add(label);
		
		

	}

}