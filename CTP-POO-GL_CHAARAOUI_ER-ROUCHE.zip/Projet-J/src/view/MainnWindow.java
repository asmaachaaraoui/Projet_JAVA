package view;
import java.awt.*;


import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.*;

import model.AbsenceDao;
import model.Connect;
import com.jgoodies.forms.factories.DefaultComponentFactory;

import view.AdminWindow;
import view.UserWindow;
import model.UsersDao;
public class MainnWindow {

	/**
	 * Declaration des variables Globales.
	 */
	 public JFrame frame;
	 JTextField textField;
	 UsersDao userDao;
	 JPasswordField passwordField;
	 String ad="administrateur";
    ResultSet rs;
	
    
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainnWindow window = new MainnWindow();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	
	public MainnWindow() {
		initialize();
		try {
			userDao = new UsersDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
	}
	
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setBackground(new Color(211, 211, 211));
		frame.setBounds(100, 100, 578, 482);
		frame.getContentPane().setLayout(null);
		
		JLabel lblLogin = new JLabel("Login :");
		lblLogin.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblLogin.setForeground(new Color(255, 255, 255));
		lblLogin.setBounds(270, 144, 79, 22);
		frame.getContentPane().add(lblLogin);
		
		JLabel lblMotDePasse = new JLabel("Mot De Passe :");
		lblMotDePasse.setForeground(new Color(255, 255, 255));
		lblMotDePasse.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblMotDePasse.setBounds(270, 213, 122, 38);
		frame.getContentPane().add(lblMotDePasse);
		
		textField = new JTextField();
		textField.setBounds(417, 147, 122, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		
		JButton btnSeConnecter = new JButton("Se Connecter");
		btnSeConnecter.setBackground(new Color(50, 205, 50));
		btnSeConnecter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
			
				 try {
					 
					 /**
						 * la verification de login System a partir de la methode Connection
						 * de la classe UserDao.
						 */
					 String login=textField.getText().toString();
					 String pass=passwordField.getText().toString();
					 
					 
					 userDao.Connection(login, pass);
					 userDao.reset(passwordField);
						userDao.reset(textField);
					frame.setVisible(false);	
					
				 }
				 catch(Exception ex) {
					 ex.printStackTrace();}
				 		
					 
			}					 
		
		});
		btnSeConnecter.setBounds(270, 321, 111, 23);
		frame.getContentPane().add(btnSeConnecter);
		
		passwordField = new JPasswordField();
		passwordField.setEchoChar('*');
		passwordField.setBounds(417, 224, 122, 20);
		frame.getContentPane().add(passwordField);
		
		JButton btnReset = new JButton("Reset");
		btnReset.setBackground(new Color(255, 0, 0));
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				userDao.reset(passwordField);
				userDao.reset(textField);
			}
		});
		btnReset.setBounds(440, 321, 110, 23);
		frame.getContentPane().add(btnReset);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(new Color(255, 140, 0));
		panel_1.setBounds(0, 0, 258, 444);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		Image photo=new ImageIcon(this.getClass().getResource("/nophoto.png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(photo));
		lblNewLabel.setBounds(39, 86, 163, 178);
		panel_1.add(lblNewLabel);
		
		JLabel lblBienvenueDansNotre = new JLabel("Bienvenue Dans Notre Club");
		lblBienvenueDansNotre.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 15));
		lblBienvenueDansNotre.setForeground(Color.WHITE);
		lblBienvenueDansNotre.setBounds(26, 285, 210, 14);
		panel_1.add(lblBienvenueDansNotre);
		
		Panel panel = new Panel();
		panel.setBounds(276, 33, 263, 66);
		frame.getContentPane().add(panel);
		
		JLabel lblConnectezvous = new JLabel("Connectez-Vous");
		lblConnectezvous.setForeground(new Color(255, 140, 0));
		lblConnectezvous.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 30));
		panel.add(lblConnectezvous);
		
		
	}
}
