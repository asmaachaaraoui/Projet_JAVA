package view;

import java.awt.BorderLayout;

import java.util.jar.*;
import net.proteanit.sql.DbUtils;

import java.awt.EventQueue;
import java.awt.ScrollPane;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.Color;
import javax.swing.table.DefaultTableModel;



import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.util.jar.*;
import java.util.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Image;

import model.Connect;
import model.Users;
import model.UsersDao;

public class GestionUsers extends JFrame {
	
	

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTable table;
	private Users user;
	private UsersDao userDao;
	private PreparedStatement pst;
	private ResultSet rs; 
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		// create the DAO
			
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GestionUsers frame = new GestionUsers();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GestionUsers() {
		try {
			userDao = new UsersDao();
		} catch (Exception exc) {
			JOptionPane.showMessageDialog(null, "Error: " , "Error", JOptionPane.ERROR_MESSAGE); 
		}
		setResizable(false);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 798, 386);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(216, 191, 216));
		panel.setBounds(10, 77, 243, 274);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("first name");
		lblNewLabel.setBounds(19, 27, 79, 14);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		
		textField.setBounds(108, 24, 123, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("last name");
		lblNewLabel_1.setBounds(19, 60, 79, 14);
		panel.add(lblNewLabel_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(108, 57, 123, 20);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("E-mail");
		lblNewLabel_2.setBounds(19, 94, 79, 14);
		panel.add(lblNewLabel_2);
		
		textField_2 = new JTextField();
		textField_2.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent arg0) {
						String sql="select firstname,lastname,pass,type,login from utilisateur where email=?";
		                try {
							 PreparedStatement pst = Connect.ConnectDb().prepareStatement(sql);
							 pst.setString(1,textField_2.getText().toString());
					         ResultSet rs =pst.executeQuery();
					         if(rs.next()) {
					         String firstname=rs.getString("firstname");
					         textField.setText(firstname);
					         String lastname=rs.getString("lastname");
					         textField_1.setText(lastname);
					         String pass=rs.getString("pass");
					         textField_3.setText(pass);
					         String type=rs.getString("type");
					         textField_4.setText(type);
					         String login=rs.getString("login");
					         textField_5.setText(login);
					         }
					} catch(SQLException e) {
						e.printStackTrace();
					}
					
			
			}
		});
		textField_2.setBounds(108, 91, 123, 20);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Password");
		lblNewLabel_3.setBounds(19, 125, 79, 14);
		panel.add(lblNewLabel_3);
		
		textField_3 = new JTextField();
		textField_3.setBounds(108, 122, 123, 20);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Type");
		lblNewLabel_4.setBounds(19, 159, 79, 14);
		panel.add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setBounds(108, 156, 123, 20);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("login");
		lblNewLabel_5.setBounds(19, 197, 79, 14);
		panel.add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(108, 194, 123, 20);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Reset");
		btnNewButton_1.setBounds(71, 240, 89, 23);
		panel.add(btnNewButton_1);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				userDao.reset(textField);
				userDao.reset(textField_1);
				userDao.reset(textField_2);
				userDao.reset(textField_3);
				userDao.reset(textField_4);
				userDao.reset(textField_5);
				
			}
		});
		btnNewButton_1.setBackground(new Color(230, 230, 250));
		
		JButton btnNewButton_2 = new JButton("Modifier");
		Image photo3=new ImageIcon(this.getClass().getResource("/Actions-user-properties-icon (1).png")).getImage();
		btnNewButton_2.setIcon(new ImageIcon(photo3));
		
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 try {String firstname=textField.getText().toString();
	            	String lastname=textField_1.getText().toString();
					String email=textField_2.getText().toString();
	            	String pass=textField_3.getText().toString();
	            	String type=textField_4.getText().toString();
	            	String login=textField_5.getText().toString();
					 userDao.updateUsers(firstname,lastname,pass,type,login,email);
	            	JOptionPane.showMessageDialog(null,"Utilisateur Modifier");
	            	
	            	userDao.UpdateTable(table);
	            	userDao.reset(textField);
					userDao.reset(textField_1);
					userDao.reset(textField_2);
					userDao.reset(textField_3);
					userDao.reset(textField_4);
					userDao.reset(textField_5);
     				
	            } catch (SQLException e1) {
	            	e1.printStackTrace();
	            }
			
			}
		});
		btnNewButton_2.setBackground(new Color(230, 230, 250));
		btnNewButton_2.setBounds(463, 287, 132, 63);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Supprimer");
		Image photo=new ImageIcon(this.getClass().getResource("/Actions-list-remove-user-icon.png")).getImage();
		btnNewButton_3.setIcon(new ImageIcon(photo));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				try {
					String email=textField_2.getText().toString();
					userDao.deleteUser(email);
						JOptionPane.showMessageDialog(null, "Utilisateur supprim�");
						userDao.reset(textField);
						userDao.reset(textField_1);
						userDao.reset(textField_2);
						userDao.reset(textField_3);
						userDao.reset(textField_4);
						userDao.reset(textField_5);
	        			userDao.UpdateTable(table);
					}catch(SQLException ex) {
						ex.printStackTrace();
					}
					
					}			
			
		});
		btnNewButton_3.setBackground(new Color(255, 228, 225));
		btnNewButton_3.setBounds(636, 287, 136, 63);
		contentPane.add(btnNewButton_3);
        
        JButton btnNewButton = new JButton("Save");
        Image photo1=new ImageIcon(this.getClass().getResource("/Actions-list-add-user-icon.png")).getImage();
		btnNewButton.setIcon(new ImageIcon(photo1));
	
        btnNewButton.setBounds(285, 287, 132, 63);
        contentPane.add(btnNewButton);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent arg0) {
        	//	Users u=new Users();
        		
        		 try {
        			 String firstname=textField.getText().toString();
  	            	String lastname=textField_1.getText().toString();
        			 String email=textField_2.getText().toString();
 	            	String pass=textField_3.getText().toString();
 	            	String type=textField_4.getText().toString();
 	            	String login=textField_5.getText().toString();
        			 if(!textField.getText().equals("") && !textField_1.getText().equals("") && 
        					 !textField_2.getText().equals("") && !textField_3.getText().equals("") 
        					 && !textField_4.getText().equals("") && !textField_5.getText().equals("")) 
        			 {
        			    userDao.addUser(firstname,lastname,email,pass,type,login);
        			    JOptionPane.showMessageDialog(null, "Utilisateur ajout�");
        			    userDao.reset(textField);
						userDao.reset(textField_1);
						userDao.reset(textField_2);
						userDao.reset(textField_3);
						userDao.reset(textField_4);
						userDao.reset(textField_5);
        				userDao.UpdateTable(table);
        			 } 
        			 
        			 else {
        			  JOptionPane.showMessageDialog(null, "Veuillez Inserer tout les champs","ERROR",JOptionPane.ERROR_MESSAGE);
        			 }
        		 }
        		 catch(Exception ex) {
        			 JOptionPane.showMessageDialog(btnNewButton, ex.getMessage(),"ERROR",JOptionPane.ERROR_MESSAGE);}
        		 
        		 
        		 
        		 
        }});
        btnNewButton.setBackground(new Color(240, 248, 255));
        
        JLabel lblNewLabel_7 = new JLabel("");
        lblNewLabel_7.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
   
                userDao.UpdateTable(table);
        	}
        });
        Image photo2=new ImageIcon(this.getClass().getResource("/Repeat-3-2-icon.png")).getImage();
		lblNewLabel_7.setIcon(new ImageIcon(photo2));
        lblNewLabel_7.setBounds(720, 65, 41, 41);
        contentPane.add(lblNewLabel_7);
        
        JPanel panel_2 = new JPanel();
        panel_2.setBackground(new Color(218, 112, 214));
        panel_2.setBounds(10, 11, 775, 55);
        contentPane.add(panel_2);
        panel_2.setLayout(null);
        
        JLabel lblGestionUtilisateurs = new JLabel("Gestion Utilisateurs");
        lblGestionUtilisateurs.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 21));
        lblGestionUtilisateurs.setBounds(308, 11, 380, 33);
        panel_2.add(lblGestionUtilisateurs);
        
        JLabel lblNewLabel_6 = new JLabel("");
        lblNewLabel_6.setBounds(10, 12, 65, 32);
        panel_2.add(lblNewLabel_6);
        lblNewLabel_6.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent arg0) {
        		AdminWindow a=new AdminWindow();
        		a.frame.setVisible(true);
        		setVisible(false);
        	}
        });
        Image photo5=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		 lblNewLabel_6.setIcon(new ImageIcon(photo5));
        
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(285, 105, 500, 171);
        contentPane.add(scrollPane);
        
        table=new JTable(new DefaultTableModel(
        	new Object[][] {
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        		{null, null, null, null, null, null, null},
        	},
        	new String[] {
        		"Id", "First name", "Last name", "E-mail", "Password", "Type", "Login"
        	}
        ));
        table.addMouseListener(new MouseAdapter() {
        	@Override
        	public void mouseClicked(MouseEvent e) {
        		//affiche le nombre de la ligne
        		int ligne=table.getSelectedRow();
        		//JOptionPane.showMessageDialog(null, ligne);
        		String firstname=table.getModel().getValueAt(ligne,1).toString();
        		String lastname=table.getModel().getValueAt(ligne,2).toString();
        		String Email=table.getModel().getValueAt(ligne,3).toString();
        		String pass=table.getModel().getValueAt(ligne,4).toString();
        		String type=table.getModel().getValueAt(ligne,5).toString();
        		String login=table.getModel().getValueAt(ligne,6).toString();
        		textField.setText(firstname);
        		textField_1.setText(lastname);
        		textField_2.setText(Email);
        		textField_3.setText(pass);
        		textField_4.setText(type);
        		textField_5.setText(login );
        		
        	
        	}
        });
        scrollPane.add(table);
        scrollPane.setViewportView(table);
        
        JLabel lblNewLabel_8 = new JLabel("Table Des Diff\u00E9rents Utilisateurs :\r\n");
        lblNewLabel_8.setFont(new Font("Times New Roman", Font.PLAIN, 13));
        lblNewLabel_8.setBackground(new Color(240, 240, 240));
        lblNewLabel_8.setBounds(285, 90, 190, 14);
        contentPane.add(lblNewLabel_8);
		
		
	}
	
	

}


