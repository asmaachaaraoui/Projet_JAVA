package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JEditorPane;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Bureau {

	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bureau window = new Bureau();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Bureau() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 651, 417);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(30, 144, 255));
		panel.setBounds(0, 0, 645, 67);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Les Diff\u00E9rents Membres du Bureau");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(160, 11, 321, 45);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Chaque Bureau de club est compos\u00E9 de:");
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(10, 77, 300, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblPrsident = new JLabel("Pr\u00E9sident:");
		lblPrsident.setForeground(new Color(0, 0, 255));
		lblPrsident.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblPrsident.setBounds(20, 104, 85, 14);
		frame.getContentPane().add(lblPrsident);
		
		JLabel lblNewLabel_2 = new JLabel("Vice Pr\u00E9sident:");
		lblNewLabel_2.setForeground(new Color(0, 0, 255));
		lblNewLabel_2.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblNewLabel_2.setBounds(20, 159, 106, 14);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblSecretaire = new JLabel("Secretaire:");
		lblSecretaire.setForeground(new Color(0, 0, 255));
		lblSecretaire.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblSecretaire.setBounds(20, 216, 85, 14);
		frame.getContentPane().add(lblSecretaire);
		
		JLabel lblTrsorier = new JLabel("Tr\u00E9sorier:");
		lblTrsorier.setForeground(new Color(0, 0, 255));
		lblTrsorier.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblTrsorier.setBounds(20, 260, 85, 14);
		frame.getContentPane().add(lblTrsorier);
		
		JLabel lblLeChargDe = new JLabel("Le charg\u00E9 de communication:");
		lblLeChargDe.setForeground(new Color(0, 0, 255));
		lblLeChargDe.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 13));
		lblLeChargDe.setBounds(20, 306, 186, 14);
		frame.getContentPane().add(lblLeChargDe);
		
		JLabel lblNewLabel_3 = new JLabel("-Represente le club et en pr\u00E9side les r\u00E9unions.\r\n");
		lblNewLabel_3.setBounds(100, 102, 238, 19);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblPrpareLordre = new JLabel("- Pr\u00E9pare l'ordre du jour des r\u00E9unions ordinaire.");
		lblPrpareLordre.setBounds(325, 104, 300, 14);
		frame.getContentPane().add(lblPrpareLordre);
		
		JLabel lblAssumeLa = new JLabel("-Assume la responsabilit\u00E9 des actions et des activit\u00E9s du club");
		lblAssumeLa.setBounds(100, 127, 424, 14);
		frame.getContentPane().add(lblAssumeLa);
		
		JLabel lblNewLabel_4 = new JLabel("- Remplace provisoirement le pr\u00E9sident en cas d\u2019absence ou d\u2019emp\u00EAchement temporaire.");
		lblNewLabel_4.setBounds(110, 159, 525, 14);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("-R\u00E9dige le rapport des activit\u00E9s du club qui devra \u00EAtre approuv\u00E9 par le bureau");
		lblNewLabel_5.setBounds(109, 184, 516, 14);
		frame.getContentPane().add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("- Veille \u00E0 la gestion de la caisse du club et en dresse la comptabilit\u00E9.");
		lblNewLabel_6.setBounds(104, 260, 393, 14);
		frame.getContentPane().add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("- Responsable des d\u00E9penses non comptabilis\u00E9es du club.");
		lblNewLabel_7.setBounds(106, 281, 357, 14);
		frame.getContentPane().add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("- R\u00E9dige les comptes-rendus de toutes les r\u00E9unions ;\r\n");
		lblNewLabel_8.setBounds(100, 216, 322, 14);
		frame.getContentPane().add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("- Note les noms des membres pr\u00E9sents aux r\u00E9unions.");
		lblNewLabel_9.setBounds(100, 235, 322, 14);
		frame.getContentPane().add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("- S\u2019occupe de la gestion des r\u00E9seaux sociaux du club ;");
		lblNewLabel_10.setBounds(202, 306, 335, 14);
		frame.getContentPane().add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("- S\u2019occupe de la communication des activit\u00E9s et des affiches du club");
		lblNewLabel_11.setBounds(202, 325, 388, 14);
		frame.getContentPane().add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("");
		lblNewLabel_12.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AdminWindow a=new AdminWindow();
        		a.frame.setVisible(true);
        		frame.setVisible(false);
				
			}
		});
		Image photo3=new ImageIcon(this.getClass().getResource("/Back-2-2-icon.png")).getImage();
		lblNewLabel_12.setIcon(new ImageIcon(photo3));
		
		lblNewLabel_12.setBounds(10, 346, 54, 32);
		frame.getContentPane().add(lblNewLabel_12);
	}
}
